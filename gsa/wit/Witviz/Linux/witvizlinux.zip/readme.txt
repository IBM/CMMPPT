An example script to run witviz is in "runwitviz". Note that you may have to modify this depending on your environment.
